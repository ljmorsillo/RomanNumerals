﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RomanNumerals
{
    public class Operations
    {
        /**
         * Function that will take number anc convert it to roman numewrals
         **/
        static string ConvertToRoman(int numToConvert)
        {
            string result = "MCMVII";
            char[] numberAsChars = numToConvert.ToString().ToCharArray();
            return result;
        }
    }
}
